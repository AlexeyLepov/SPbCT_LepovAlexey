package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println(1e20f*1e20f);
        System.out.println(-1e200*1e200);
    }
}
