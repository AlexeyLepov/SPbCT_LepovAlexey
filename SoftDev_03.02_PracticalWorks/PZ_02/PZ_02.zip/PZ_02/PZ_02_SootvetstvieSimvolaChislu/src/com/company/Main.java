package com.company;

public class Main {

    public static void main(String[] args) {

            char symb1=1067;
            char symb2 ='Ы';

            System.out.println("symb1 contains "+ symb1);
            System.out.println("symb2 contains "+ symb2);
    }
}
