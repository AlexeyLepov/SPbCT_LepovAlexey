package com.company;

public class Main {

    public static void main(String[] args) {
        char c='A';

        System.out.println(c);
        System.out.println(c+1);
        System.out.println("c="+c);
        System.out.println('c'+'='+c);
    }
}
