package com.company;

public class Main {

    public static void main(String[] args) {
        char ch = 'J';
        int intCh = (int) ch;

        System.out.println("J corresponds with "+ intCh);

    }
}
