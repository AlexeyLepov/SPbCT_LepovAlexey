package com.company;

public class Main {

    public static void main(String[] args) {
        int i = 35;
        String str = Integer.toString(i);
        System.out.println(str);
    }
}