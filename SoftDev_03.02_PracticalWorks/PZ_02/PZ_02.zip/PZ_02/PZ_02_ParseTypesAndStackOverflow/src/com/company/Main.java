package com.company;

public class Main {

    public static void main(String[] args) {
        byte x=-128;
        System.out.println(-x);

        byte y=127;
        System.out.println(++y);
    }
}
