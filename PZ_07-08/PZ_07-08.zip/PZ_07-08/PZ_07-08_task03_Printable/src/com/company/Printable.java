package com.company;

public interface Printable {
    void println();
}
