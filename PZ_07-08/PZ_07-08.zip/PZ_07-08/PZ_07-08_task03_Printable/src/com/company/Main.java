package com.company;

public class Main {

    public static void main(String[] args) {

    Car c1 = new Car("МЗМА","Москвич-408","Четырёхдверный седан",5000,1964);
        c1.println();
    Car c2 = new Car("ГАЗ","Чайка","Четырёхдверный седан",1000,1959);
        c2.println();
    Car c3 = new Car("ГАЗ","Победа","Фастбэк",15000,1956);
        c3.println();
    }
}
