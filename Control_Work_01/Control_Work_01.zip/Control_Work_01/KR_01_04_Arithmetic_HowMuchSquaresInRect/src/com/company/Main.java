package com.company;

public class Main {

    public static void main(String[] args) {
    int x = 647;
    int y = 170;
    int num = (x * y) / (30*30);
    System.out.println(num);
    }
}
