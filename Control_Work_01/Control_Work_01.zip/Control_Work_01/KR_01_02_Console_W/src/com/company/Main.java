package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("\nВывод на экран буквы «W»:");
        System.out.println("======================");
        System.out.println("  *               *   ");
        System.out.println("   *             *    ");
        System.out.println("    *     *     *     ");
        System.out.println("     *   * *   *      ");
        System.out.println("      * *   * *       ");
        System.out.println("       *     *        ");
        System.out.println("======================");
    }
}
