class Automobile implements Vehicle {
    public void go() {
        System.out.println("Automobile go!");
    }
}