import java.lang.*;
import java.lang.IllegalAccessException;

interface Vehicle {
    void go();
}


