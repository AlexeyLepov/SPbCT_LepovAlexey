public class RussianBehavior implements Behavior {
    public RussianBehavior() {
    }
    public String getBehavior(){
        return "Русский вариант поведения";
    }
    public String getCapital(){
        return "Москва";
    }
}