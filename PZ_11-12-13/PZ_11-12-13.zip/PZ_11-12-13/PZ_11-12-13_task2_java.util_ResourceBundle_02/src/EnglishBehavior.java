public class EnglishBehavior implements Behavior{
    public EnglishBehavior() {
    }
    public String getBehavior(){
        return "English behavior";
    }
    public String getCapital(){
        return "London";
    }
}