public interface Behavior {
    public String getBehavior();
    public String getCapital();
}